package com.kg.mmar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MMarApplication {

    public static void main(String[] args) {
        SpringApplication.run(MMarApplication.class, args);
    }

}
