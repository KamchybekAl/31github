package com.kg.mmar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MMarApplicationTests {

    @Test
    void contextLoads() {
    }

}
