package com.kg.mmar.entity.enams;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ProductCategory {
    CAKE,
    JUICE,
    ICE_CREAM
}
