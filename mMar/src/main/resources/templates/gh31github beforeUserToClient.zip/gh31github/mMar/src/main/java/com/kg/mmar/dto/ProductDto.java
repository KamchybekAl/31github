package com.kg.mmar.dto;

import lombok.Data;

@Data
public class ProductDto {
    private Long id;
    private Double weight;
    private Double quantity;
}
